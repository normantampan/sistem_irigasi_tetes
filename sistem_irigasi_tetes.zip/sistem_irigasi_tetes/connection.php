<?php

$hostname	= "localhost";
$username	= "root";
$password	= "";
$database   = "sistem_irigasi_db";

$con = mysqli_connect($hostname, $username, $password, $database);

if ($con->connect_error) {
	echo "Gagal Terkoneksi karena ERROR pada :".mysqli_error($con);
	
} else {
	// echo "berhasil";
}
?>
