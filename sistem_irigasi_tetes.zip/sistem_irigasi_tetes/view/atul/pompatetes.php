<!DOCTYPE html>
<html lang="en">
<?php
include '../../controllers/config.php';
?>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>SB Admin 2 - Charts</title>

    <!-- Custom fonts for this template-->
    <link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.0/css/jquery.dataTables.css" />

    <!-- Custom styles for this template-->
    <link href="../../css/sb-admin-2.min.css" rel="stylesheet" />
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../../index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">
                    SISTEM IRIGASI TETES
                </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0" />

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../../index.html">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider" />

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" />
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">
                                            December 12, 2019
                                        </div>
                                        <span class="font-weight-bold">A new monthly report is ready
                                            to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">
                                            December 7, 2019
                                        </div>
                                        $290.29 has been deposited into your
                                        account!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">
                                            December 2, 2019
                                        </div>
                                        Spending Alert: We've noticed
                                        unusually high spending for your
                                        account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <!-- Nav Item - Messages -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope fa-fw"></i>
                                <!-- Counter - Messages -->
                                <span class="badge badge-danger badge-counter">7</span>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                                <h6 class="dropdown-header">
                                    Message Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_1.svg" alt="..." />
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div class="font-weight-bold">
                                        <div class="text-truncate">
                                            Hi there! I am wondering if you
                                            can help me with a problem I've
                                            been having.
                                        </div>
                                        <div class="small text-gray-500">
                                            Emily Fowler · 58m
                                        </div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_2.svg" alt="..." />
                                        <div class="status-indicator"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">
                                            I have the photos that you
                                            ordered last month, how would
                                            you like them sent to you?
                                        </div>
                                        <div class="small text-gray-500">
                                            Jae Chun · 1d
                                        </div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_3.svg" alt="..." />
                                        <div class="status-indicator bg-warning"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">
                                            Last month's report looks great,
                                            I am very happy with the
                                            progress so far, keep up the
                                            good work!
                                        </div>
                                        <div class="small text-gray-500">
                                            Morgan Alvarez · 2d
                                        </div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60" alt="..." />
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">
                                            Am I a good boy? The reason I
                                            ask is because someone told me
                                            that people say this to all
                                            dogs, even if they aren't
                                            good...
                                        </div>
                                        <div class="small text-gray-500">
                                            Chicken the Dog · 2w
                                        </div>
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span>
                                <img class="img-profile rounded-circle" src="../../img/undraw_profile.svg" />
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">
                        Sistem Irigasi Tetes
                    </h1>
                    <!-- Content Row -->
                    <div class="row d-flex justify-content-center">
                        <div class="col-xl">
                            <!-- Tables 1 -->
                            <?php $data = mysqli_query($koneksi, "SELECT * FROM komdat"); ?>
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Komunikasi Data
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="display cell-border" id="example" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Jarak</th>
                                                    <th>Throughput (%)</th>
                                                    <th>PDR (%)</th>
                                                    <th>Delay (s)</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Jarak</th>
                                                    <th>Throughput (%)</th>
                                                    <th>PDR (%)</th>
                                                    <th>Delay (s)</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php $no = 1;
                                                while ($d = mysqli_fetch_array($data)) { ?>
                                                    <tr>
                                                        <td><?= $no++ ?></td>
                                                        <td><?= $d['jarak'] ?></td>
                                                        <td><?= $d['throughput'] ?></td>
                                                        <td><?= $d['pdr'] ?></td>
                                                        <td><?= $d['delay'] ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Bar Chart -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Diagram Throughput dan PDR
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="">
                                        <canvas id="myChart" height="120vh"></canvas>
                                    </div>
                                </div>
                            </div>
                            <!-- Area Chart -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Delay
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="">
                                        <canvas id="myChart1" height="120vh"></canvas>
                                    </div>
                                </div>
                            </div>
                            <!-- Tables 2 -->
                            <?php $data = mysqli_query($koneksi, "SELECT * FROM datapower"); ?>
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Evaluasi dan Hasil Data Power
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="display cell-border" id="example1" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2">No</th>
                                                    <th rowspan="2">Cahaya</th>
                                                    <th rowspan="2">Suhu (c)</th>
                                                    <th style="border-right: 1px solid rgba(0, 0, 0, 0.3);" class="text-center" colspan="2">Solar Panel</th>
                                                    <th class="text-center" colspan="5">Baterai</th>
                                                </tr>
                                                <tr>
                                                    <th>Arus (A)</th>
                                                    <th style="border-right: 1px solid rgba(0, 0, 0, 0.3);">Tegangan (V)</th>
                                                    <th>Arus (A)</th>
                                                    <th>Tegangan (V)</th>
                                                    <th>Throughput (%)</th>
                                                    <th>PDR (%)</th>
                                                    <th>Delay (s)</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th rowspan="2">No</th>
                                                    <th rowspan="2">Cahaya</th>
                                                    <th rowspan="2">Suhu (c)</th>
                                                    <th class="text-center" colspan="2">Solar Panel</th>
                                                    <th class="text-center" colspan="5">Baterai</th>
                                                </tr>
                                                <tr>
                                                    <th>Arus (A)</th>
                                                    <th>Tegangan (V)</th>
                                                    <th>Arus (A)</th>
                                                    <th>Tegangan (V)</th>
                                                    <th>Throughput (%)</th>
                                                    <th>PDR (%)</th>
                                                    <th>Delay (s)</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php $no = 1;
                                                while ($d = mysqli_fetch_array($data)) { ?>
                                                    <tr>
                                                        <td><?= $no++ ?></td>
                                                        <td><?= $d['cahaya'] ?></td>
                                                        <td><?= $d['suhu'] ?></td>
                                                        <td><?= $d['s_arus'] ?></td>
                                                        <td><?= $d['s_tegangan'] ?></td>
                                                        <td><?= $d['b_arus'] ?></td>
                                                        <td><?= $d['b_tegangan'] ?></td>
                                                        <td><?= $d['b_throughput'] ?></td>
                                                        <td><?= $d['b_pdr'] ?></td>
                                                        <td><?= $d['b_delay'] ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Tables 3 -->
                            <?php $data = mysqli_query($koneksi, "SELECT * FROM kondisicuaca"); ?>
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Kondisi Cuaca dengan Air yang dugunakan dan rata-rata water level
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="display" id="example2" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Cahaya</th>
                                                    <th>Suhu (c)</th>
                                                    <th>Air Yang Digunakan (ml)</th>
                                                    <th>Rata-Rata Water Level (Ohm)</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Cahaya</th>
                                                    <th>Suhu (c)</th>
                                                    <th>Air Yang Digunakan (ml)</th>
                                                    <th>Rata-Rata Water Level (Ohm)</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php $no = 1;
                                                while ($d = mysqli_fetch_array($data)) { ?>
                                                    <tr>
                                                        <td><?= $no++ ?></td>
                                                        <td><?= $d['cahaya'] ?></td>
                                                        <td><?= $d['suhu'] ?></td>
                                                        <td><?= $d['air'] ?></td>
                                                        <td><?= $d['average'] ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Tables 4 -->
                            <?php $data = mysqli_query($koneksi, "SELECT * FROM konsumsilistrik"); ?>
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Perbandingan konsumsi listrik
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="display" id="example3" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Jumlah Pompa</th>
                                                    <th>Air Yang Disuplay (ml)</th>
                                                    <th>Rata-Rata Arus (A)</th>
                                                    <th>Rata-Rata Tegangan (V)</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Jumlah Pompa</th>
                                                    <th>Air Yang Disuplay (ml)</th>
                                                    <th>Rata-Rata Arus (A)</th>
                                                    <th>Rata-Rata Tegangan (V)</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php $no = 1;
                                                while ($d = mysqli_fetch_array($data)) { ?>
                                                    <tr>
                                                        <td><?= $no++ ?></td>
                                                        <td><?= $d['pompa'] ?></td>
                                                        <td><?= $d['air'] ?></td>
                                                        <td><?= $d['arus'] ?></td>
                                                        <td><?= $d['tegangan'] ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        Ready to Leave?
                    </h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    Select "Logout" below if you are ready to end your
                    current session.
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">
                        Cancel
                    </button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <?php
    $data = mysqli_query($koneksi, "SELECT * FROM komdat");
    $mydata = array();
    while ($row = $data->fetch_assoc()) {
        $mydata[] = $row;
    }
    $mydata = json_encode($mydata);
    ?>
    <!-- Bootstrap core JavaScript-->
    <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="./../js/sb-admin-2.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script>

    <!-- Page level plugins -->
    <script src="../../vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <!-- <script src="../../js/demo/chart-area-demo.js"></script>
    <script src="../../js/demo/chart-pie-demo.js"></script>
    <script src="../../js/demo/atul/bar.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js" integrity="sha512-QSkVNOCYLtj73J4hbmVoOV6KVZuMluZlioC+trLpewV8qMjsWqlIQvkn1KGX2StWvPMdWGBqim1xlC8krl1EKQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $(document).ready(function() {
            $("#example").DataTable();
        });
        $(document).ready(function() {
            $("#example1").DataTable();
        });
        $(document).ready(function() {
            $("#example2").DataTable();
        });
        $(document).ready(function() {
            $("#example3").DataTable();
        });
    </script>
    <script>
        var datas = <?= $mydata ?>;
        const ctx = document.getElementById('myChart');
        var jarak = Object.keys(datas).map((key) => datas[key].jarak);
        var thp = Object.keys(datas).map((key) => datas[key].throughput);
        var delay = Object.keys(datas).map((key) => datas[key].delay);
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: jarak,
                datasets: [{
                    label: 'Throughput (%)',
                    data: thp,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.2)',
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                    ],
                    borderWidth: 1
                }, {
                    label: 'PDR (%)',
                    data: [parseFloat(datas[0].pdr), parseFloat(datas[1].pdr) ?? 0, parseFloat(datas[2].pdr) ?? 0, parseFloat(datas[3].pdr) ?? 0, parseFloat(datas[4].pdr) ?? 0, parseFloat(datas[5].pdr) ?? 0],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        const ctx1 = document.getElementById('myChart1');
        const myChart1 = new Chart(ctx1, {
            type: 'line',
            data: {
                labels: jarak,
                datasets: [{
                    label: 'Delay (s)',
                    data: delay,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.2)',
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                    ],
                    borderWidth: 1,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Time (s)'
                        },
                    },
                }
            }
        });
    </script>
</body>

</html>