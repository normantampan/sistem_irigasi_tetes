<?php
    include 'controllers/config.php';

     if(isset($_POST["import"])){
         $fileName=$_FILES["file"]["tmp_name"];

         if ($_FILES["file"]["size"]>0) {
             $file=fopen($fileName, "r");

             while (($column=fgetcsv($file,10000, ","))!==FALSE) {
                 # code...
                 $sqlInsert="INSERT INTO data_soil1 (waktu,col2,col3,col4) values('".$column[0]."','".$column[1]."','".$column[2]."','".$column[3]."')";
                 $result=mysqli_query($koneksi,$sqlInsert);

                 if (!empty($result)) {
                     # code...
                     ?>
                        <script>
                            alert('success')
                        </script>
                     <?php
                    
                 }else{
                    ?>
                        <script>
                            alert('failed')
                        </script>
                     <?php
                 }
             }
             # code...
         }
     }
?>